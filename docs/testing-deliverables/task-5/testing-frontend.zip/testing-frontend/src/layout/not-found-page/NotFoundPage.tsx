import { Text } from "@chakra-ui/react";

export function NotFoundPage() {
  return <Text fontSize="6xl">Page not Found 404</Text>;
}
