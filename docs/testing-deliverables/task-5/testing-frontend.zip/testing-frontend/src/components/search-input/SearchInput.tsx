import { Input } from "@chakra-ui/react";

export function SearchInput() {
  return <Input variant="inputRollCall" placeholder="Search" size="lg" />;
}
