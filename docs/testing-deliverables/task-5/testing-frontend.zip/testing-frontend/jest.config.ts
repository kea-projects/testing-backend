import type { Config } from "@jest/types";

// Sync object
/**code coverage is ignoring the mock files*/
/**code coverage is ignoring theme for chakra*/
const config: Config.InitialOptions = {
  verbose: true,
};
export default config;
