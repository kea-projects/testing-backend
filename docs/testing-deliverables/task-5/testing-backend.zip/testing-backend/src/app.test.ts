// Dummy test to validate CI flow
describe("Calculator tests", () => {
  test("adding 1 + 2 should return 3", () => {
    expect((1 + 2)).toBe(3);
  });
});
